# Golgi localization — purple glass explanation series

## Style Prompt
Continue the approved left-speaker/right-panel composition, pale purple translucent rounded glass, plum technical labels and restrained diagram entrances. Restore the approved earlier clips: keep the speaker and left foreground sharp, soften the peripheral background using a blurred silent duplicate, and use a 26px glass-panel backdrop blur. Do not mirror or tile the laboratory background. Keep the complete source narration and avoid spoken-word captions.

## Colors
- #eee7fa: purple glass
- #523466: headings and labels
- #8152a2: active elements
- #ae90c2: outlines
- #f8f3fd: inset backgrounds

## Typography
Local DejaVu Sans regular/bold; 43px headings and 25–30px diagram labels.

## Scientific structure
First show a schematic Golgi stack with a selected enzyme position, without assigning a particular cisterna identity. Then show the type-II membrane topology underlying the supplied CTS explanation: N-terminal cytoplasmic tail in the cytosol, one transmembrane segment crossing the Golgi membrane, stem and catalytic domain in the lumen. Reveal each segment at its spoken cue; finally summarize tail/TM/stem as a modular CTS localization handle. The diagrams are conceptual, without specific residue sequences, quantitative values, or universal localization claims.

## What NOT to Do
- No mirrored background extensions, tiled laboratory features, or duplicated sharp background details.
- Keep the speaker sharp; apply softening only to the background layer and glass panel.
- No full-video decorative border.
- No narration subtitles or added music.
- Do not place the catalytic domain or stem in the cytosol.
- Do not imply a named Golgi cisterna or a specific enzyme sequence.
