# Golgi localization — purple glass explanation series

## Style Prompt
Continue the approved left-speaker/right-panel composition, pale purple translucent rounded glass, plum technical labels and restrained diagram entrances. The user explicitly requested that the laboratory background remain sharp: use full-resolution unblurred footage for both layers and disable panel backdrop blur. Keep the complete source narration and avoid spoken-word captions.

## Colors
- #eee7fa: purple glass
- #523466: headings and labels
- #8152a2: active elements
- #ae90c2: outlines
- #f8f3fd: inset backgrounds

## Typography
Local DejaVu Sans regular/bold; 43px headings and 25–30px diagram labels.

## Scientific structure
First show a schematic Golgi stack with a selected enzyme position, without assigning a particular cisterna identity. Then show the type-II membrane topology underlying the supplied CTS explanation: N-terminal cytoplasmic tail in the cytosol, one transmembrane segment crossing the Golgi membrane, stem and catalytic domain in the lumen. Reveal each segment at its spoken cue; finally summarize tail/TM/stem as a modular CTS localization handle. The diagrams are conceptual, without specific residue sequences, quantitative values, or universal localization claims.

## What NOT to Do
- No background blur, soft-focus footage, or CSS backdrop blur.
- No full-video decorative border.
- No narration subtitles or added music.
- Do not place the catalytic domain or stem in the cytosol.
- Do not imply a named Golgi cisterna or a specific enzyme sequence.
