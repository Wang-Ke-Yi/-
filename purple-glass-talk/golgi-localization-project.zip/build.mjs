import {readFileSync,writeFileSync} from 'node:fs';
const duration=16.5;
const timing=JSON.parse(readFileSync(new URL('word-timings.json',import.meta.url),'utf8'));
const at=word=>timing.find(w=>w.word===word).start;
const ink='#523466',accent='#8152a2',edge='#ae90c2',pale='#f8f3fd',node='#b891d0';
const cisternae=[108,195,282,369].map((y,i)=>`<g class="cisterna"><path d="M 133 ${y} C 255 ${y-34} 550 ${y-34} 674 ${y} Q 726 ${y+24} 674 ${y+48} C 550 ${y+23} 255 ${y+23} 133 ${y+48} Q 80 ${y+24} 133 ${y} Z" fill="${['#eee3f7','#e6d7f1','#ede2f6','#f5effa'][i]}" stroke="${edge}" stroke-width="2"/></g>`).join('');
const overview=`<svg width="828" height="548" viewBox="0 0 828 548" aria-hidden="true">
 <g id="golgi-stack">${cisternae}</g>
 <g id="golgi-label"><text x="414" y="497" font-size="30" font-weight="700" text-anchor="middle" fill="${ink}">Golgi apparatus</text></g>
 <g id="selected-enzyme"><path d="M500 172v13" fill="none" stroke="${accent}" stroke-width="7" stroke-linecap="round"/><path d="M511 185a18 18 0 1 0 0 28l-9-14Z" fill="${accent}"/><circle cx="516" cy="194" r="4" fill="${node}"/></g>
 <g id="position-callout"><rect x="461" y="22" width="292" height="55" rx="27" fill="${pale}" stroke="${edge}" stroke-width="1.5"/><text x="607" y="58" text-anchor="middle" font-size="26" font-weight="700" fill="${ink}">Correct position</text><path d="M607 77V112L528 170" fill="none" stroke="${accent}" stroke-width="2"/><circle cx="501" cy="199" r="38" fill="none" stroke="${accent}" stroke-width="2" stroke-dasharray="5 5"/></g>
</svg>`;
const lipidHeads=Array.from({length:30},(_,i)=>40+i*26).filter(x=>x<390||x>440).map(x=>`<g><circle cx="${x}" cy="201" r="4" fill="${pale}" stroke="${edge}" stroke-width="1"/><path d="M${x-1.5} 206v12m3-12v12" stroke="${edge}" stroke-width="1"/><circle cx="${x}" cy="239" r="4" fill="${pale}" stroke="${edge}" stroke-width="1"/><path d="M${x-1.5} 234v-12m3 12v-12" stroke="${edge}" stroke-width="1"/></g>`).join('');
const topology=`<svg width="828" height="548" viewBox="0 0 828 548" aria-hidden="true">
 <g id="topology-base"><text x="34" y="54" fill="${ink}" font-size="19" letter-spacing="1">CYTOSOL</text>
 <rect x="18" y="191" width="792" height="59" rx="6" fill="#e5d7f1" stroke="${edge}" stroke-width="1.2"/>${lipidHeads}
 <text x="34" y="397" fill="${ink}" font-size="19" letter-spacing="1">GOLGI LUMEN</text>
 <path d="M357 354C369 329 420 326 452 346 479 361 491 393 469 415 448 438 399 443 369 423 340 405 340 380 357 354Z" fill="${node}" stroke="${accent}" stroke-width="2"/>
 <path d="M489 382H527" stroke="${edge}" stroke-width="1.5"/><text x="541" y="390" fill="${ink}" font-size="25">Catalytic domain</text></g>
 <g id="tail-segment"><path d="M367 90C378 112 401 124 409 151L414 190" fill="none" stroke="${accent}" stroke-width="10" stroke-linecap="round"/>
 <text x="349" y="78" fill="${ink}" font-size="18">N</text><path d="M286 130H389" fill="none" stroke="${edge}" stroke-width="1.5"/><text x="34" y="139" fill="${ink}" font-size="25" font-weight="700">Cytoplasmic tail</text></g>
 <g id="tm-segment"><path d="M414 190L404 198 424 207 404 217 424 227 404 237 414 251" fill="none" stroke="${accent}" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/><path d="M434 217H467" fill="none" stroke="${edge}" stroke-width="1.5"/><text x="480" y="226" fill="${ink}" font-size="25" font-weight="700">Transmembrane</text></g>
 <g id="stem-segment"><path d="M414 252C397 274 435 290 416 311L414 334" fill="none" stroke="${node}" stroke-width="10" stroke-linecap="round"/><path d="M184 301H394" fill="none" stroke="${edge}" stroke-width="1.5"/><text x="91" y="310" fill="${ink}" font-size="25" font-weight="700">Stem</text></g>
 <g id="module"><text x="414" y="467" text-anchor="middle" font-size="25" font-weight="700" fill="${ink}">Modular CTS handle</text>
 <rect x="30" y="485" width="768" height="53" rx="14" fill="#eee3f7" stroke="${edge}" stroke-width="1.5"/>
 <path d="M286 486v51m256-51v51" stroke="${edge}" stroke-width="1.2"/>
 <text x="158" y="521" fill="${ink}" font-size="25" font-weight="700" text-anchor="middle">Tail</text><text x="414" y="521" fill="${ink}" font-size="25" font-weight="700" text-anchor="middle">TM</text><text x="670" y="521" fill="${ink}" font-size="25" font-weight="700" text-anchor="middle">Stem</text></g>
</svg>`;
const css=readFileSync(new URL('layout.css',import.meta.url),'utf8');
const switchAt=at('native')-.35;
const html=`<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=1920,height=1080"><title>Golgi localization — purple glass explanation</title><script src="assets/gsap.min.js"></script><style>${css}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="${duration}" data-width="1920" data-height="1080">
 <div class="background" data-layout-allow-overflow><video id="background-video" class="clip" src="background.mp4" data-start="0" data-duration="${duration}" data-track-index="0" muted playsinline></video></div>
 <div class="speaker-zone" data-layout-allow-overflow><video id="a-roll" class="clip" src="source.mp4" data-start="0" data-duration="${duration}" data-track-index="1" data-has-audio="true" playsinline></video></div>
 <aside id="panel">
  <section id="overview" class="scene"><div class="scene-content"><header class="scene-header"><p class="eyebrow">ENZYME LOCALIZATION</p><h1>Position within the Golgi</h1></header><div class="diagram">${overview}</div></div></section>
  <section id="determinants" class="scene"><div class="scene-content"><header class="scene-header"><p class="eyebrow">NATIVE CTS SEQUENCES</p><h1>Modular localization handles</h1></header><div class="diagram">${topology}</div></div></section>
  <div class="progress-rail" data-layout-ignore><div id="progress-fill"></div></div>
 </aside>
</div><script>
window.__timelines=window.__timelines||{};
const tl=gsap.timeline({paused:true});
tl.from('#panel',{opacity:0,y:12,duration:.48,ease:'power2.out'},.12);
tl.from('#overview .eyebrow',{opacity:0,y:6,duration:.3,ease:'sine.out'},.28);
tl.from('#overview h1',{opacity:0,y:10,duration:.4,ease:'power3.out'},.34);
tl.from('#golgi-stack .cisterna',{opacity:0,y:8,duration:.45,ease:'power2.out',stagger:.12},.7);
tl.from('#golgi-label',{opacity:0,duration:.35,ease:'sine.out'},1.4);
tl.from('#selected-enzyme',{opacity:0,duration:.35,ease:'power2.out'},${(at('positioned')-.1).toFixed(2)});
tl.from('#position-callout',{opacity:0,duration:.4,ease:'power1.out'},${(at('correctly')-.1).toFixed(2)});
// The topology enlargement replaces the overview through a short color dip.
tl.to('#overview',{opacity:0,duration:.12,ease:'power2.in'},${switchAt.toFixed(2)});
tl.fromTo('#determinants',{opacity:0},{opacity:1,duration:.22,ease:'power2.out'},${(switchAt+.12).toFixed(2)});
tl.from('#determinants .eyebrow',{opacity:0,y:6,duration:.28,ease:'sine.out'},${(switchAt+.18).toFixed(2)});
tl.from('#determinants h1',{opacity:0,y:8,duration:.35,ease:'power3.out'},${(switchAt+.22).toFixed(2)});
tl.from('#topology-base',{opacity:0,duration:.4,ease:'power2.out'},${(at('native')-.1).toFixed(2)});
tl.from('#tail-segment',{opacity:0,duration:.35,ease:'sine.out'},${(at('cytoplasmic')-.1).toFixed(2)});
tl.from('#tm-segment',{opacity:0,duration:.35,ease:'power3.out'},${(at('transmembrane')-.1).toFixed(2)});
tl.from('#stem-segment',{opacity:0,duration:.35,ease:'power2.out'},${(at('stem')-.1).toFixed(2)});
tl.from('#module',{opacity:0,y:7,duration:.45,ease:'sine.out'},${(at('modular')-.1).toFixed(2)});
tl.from('#progress-fill',{scaleX:0,duration:${duration-.6},ease:'none'},.3);
window.__timelines.main=tl;
</script></body></html>`;
writeFileSync(new URL('index.html',import.meta.url),html);
