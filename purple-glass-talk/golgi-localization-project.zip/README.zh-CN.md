# 第三段：高尔基体定位与 CTS 模块

沿用已确认的左侧人物、右侧紫色半透明圆角讲解面板。背景恢复为与前两段一致的柔和处理，紫色玻璃面板使用 backdrop blur。保留原片 16.5 秒完整讲解及原始 AAC 音轨，不加口播字幕或配乐。

人物与主画面整体向左重排并保持清晰，左侧画面边缘平滑过渡到虚化背景；取消右侧镜像延展。

先展示高尔基体内的定位，再放大为 II 型膜蛋白示意：N 端胞质尾位于胞质，单个跨膜区穿过高尔基体膜，stem 和催化结构域位于腔内。三个 CTS 区域随讲解逐个显示，最后汇总为模块化定位元件。该图不指定酶或具体序列，也不指定某个高尔基体层级。

`build.mjs` 生成 HTML；`layout.css` 定义已确认版式；`narration.txt` 为用户原文，`word-timings.json` 用于图解入场，不生成字幕。素材、原声音轨、字体和本地 GSAP 已包含。

需要 Node.js 22+、FFmpeg、Chrome/Chromium。执行 `bash render.sh` 检查并重新导出 `golgi-localization.mp4`。HyperFrames 固定使用 0.8.181。`source.mp4` 为清晰主画面；`background.mp4` 为缩小后虚化的静音背景副本。
