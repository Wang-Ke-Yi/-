# Promoter engineering — approved purple glass style

## Style Prompt
Continue the previous approved clip and the user's screenshot: a laboratory speaker on the left and a pale purple translucent rounded explanation panel on the right. Keep the exact layout, typography and palette from the preceding glycan-diversity clip. Use concise diagram labels without narration subtitles.

## Colors
- #eee7fa: glass panel
- #523466: headings and labels
- #8152a2: arrows and active elements
- #ae90c2: outlines
- #f8f3fd: diagram cards

## Typography
Local DejaVu Sans regular and bold; 43px headings and 27–28px diagram labels.

## Content and motion
First show complexity becoming design opportunities. At the second sentence show a promoter upstream of an enzyme-coding gene, an adjustable promoter-strength control, enzyme abundance, and catalytic capacity. Align the visual cues with the user-provided narration using local forced alignment. The change in icon count is a qualitative illustration, not measured kinetics or a claim that promoter engineering alters the enzyme's intrinsic catalytic constant.

## What NOT to Do
- No whole-video outer border.
- No spoken-word subtitles.
- No unrelated glycan structures or gene names.
- No numerical data or invented measurements.
- No replacement voice or background music.
