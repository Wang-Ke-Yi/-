# 第二段：启动子工程

沿用已确认的左侧人物讲解、右侧紫色半透明玻璃面板。保留原片 9.3 秒完整讲解及原始 AAC 音轨，不加口播字幕或配乐。图解文字只包括标题与关键词。

前半段将复杂性转化为设计机会；后半段用“启动子调节 → 酶丰度 → 催化能力”的图解配合讲解。酶图标数量和反应通量为定性示意，不是测量数据，也不表示启动子改变单个酶分子的催化常数。

`build.mjs` 为可编辑图解及动画源文件；`layout.css` 沿用前一段的版式；`narration.txt` 是用户提供的原文；`word-timings.json` 用于入场时间，不生成字幕。素材和本地 GSAP、字体位于项目中。

需要 Node.js 22+、FFmpeg 和 Chrome/Chromium。执行 `bash render.sh` 检查并重新导出 `promoter-engineering.mp4`。HyperFrames 固定使用 0.8.181。原 MOV 为浏览器兼容转成 `source.mp4`；最终音频直接复制 `original-audio.m4a`。
