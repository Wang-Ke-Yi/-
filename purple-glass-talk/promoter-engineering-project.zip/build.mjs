import {readFileSync,writeFileSync} from 'node:fs';

const duration=9.3;
const timing=JSON.parse(readFileSync(new URL('word-timings.json',import.meta.url),'utf8'));
const at=word=>timing.find(w=>w.word===word).start;
const colors={ink:'#523466',accent:'#8152a2',edge:'#ae90c2',pale:'#f8f3fd',node:'#b891d0'};
const {ink,accent,edge,pale,node}=colors;
const linkedNodes=[[105,230],[164,275],[245,221],[132,357],[250,345],[198,395],[222,297]];
const complexity=`<svg width="828" height="548" viewBox="0 0 828 548" aria-hidden="true">
 <g id="complexity"><rect x="24" y="103" width="296" height="338" rx="24" fill="${pale}" stroke="${edge}" stroke-width="1.5"/>
 <text x="172" y="153" font-size="28" font-weight="700" text-anchor="middle" fill="${ink}">Complexity</text>
 <path d="M105 230L164 275 245 221 222 297 250 345 132 357 105 230M164 275L132 357 198 395 250 345M164 275L222 297 198 395" fill="none" stroke="${edge}" stroke-width="2.4"/>
 ${linkedNodes.map(([x,y])=>`<circle cx="${x}" cy="${y}" r="10" fill="${node}" stroke="${accent}" stroke-width="2"/>`).join('')}</g>
 <g id="opportunity-arrow"><path d="M354 278H471" fill="none" stroke="${accent}" stroke-width="4"/><path d="M457 267l16 11-16 11" fill="none" stroke="${accent}" stroke-width="4" stroke-linejoin="round"/></g>
 <g id="opportunities"><rect x="506" y="103" width="296" height="338" rx="24" fill="#eee3f7" stroke="${edge}" stroke-width="1.5"/>
 <text x="654" y="148" font-size="27" font-weight="700" text-anchor="middle" fill="${ink}">Design</text><text x="654" y="181" font-size="27" font-weight="700" text-anchor="middle" fill="${ink}">opportunities</text>
 ${[244,310,376].map((y,i)=>`<path d="M552 ${y}H756" stroke="${edge}" stroke-width="5" stroke-linecap="round"/><circle id="design-knob-${i}" cx="${[600,702,638][i]}" cy="${y}" r="12" fill="${accent}" stroke="${pale}" stroke-width="2"/>`).join('')}</g>
</svg>`;

const enzyme=(x,y,id='',filled=true)=>`<g${id?` id="${id}"`:''} transform="translate(${x} ${y})"><path d="M8 -11a14 14 0 1 0 0 22L0 0Z" fill="${filled?accent:node}"/><circle cx="11" cy="-5" r="3" fill="${node}"/></g>`;
const enzymes=Array.from({length:9},(_,i)=>enzyme(485+(i%3)*83,294+Math.floor(i/3)*34,i>2?'extra-enzyme-'+i:'',i<3)).join('');
const reactionRows=[462,490,518].map((y,i)=>`<g id="reaction-${i}"><circle cx="498" cy="${y}" r="6.5" fill="${pale}" stroke="${accent}" stroke-width="1.8"/><path d="M519 ${y}H704m-9 -6 9 6-9 6" fill="none" stroke="${accent}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="732" cy="${y}" r="7" fill="${accent}"/><circle id="flux-${i}" cx="532" cy="${y}" r="3.5" fill="${accent}"/></g>`).join('');
const mechanism=`<svg width="828" height="548" viewBox="0 0 828 548" aria-hidden="true">
 <g id="promoter-gene"><path d="M35 78H798" fill="none" stroke="${edge}" stroke-width="2.2"/>
 <rect x="60" y="45" width="224" height="66" rx="13" fill="#e8daf4" stroke="${accent}" stroke-width="1.8"/><text x="172" y="86" text-anchor="middle" fill="${ink}" font-size="28" font-weight="700">Promoter</text>
 <path d="M284 78H358m-11 -8 11 8-11 8" fill="none" stroke="${accent}" stroke-width="2.6"/>
 <rect x="366" y="45" width="414" height="66" rx="13" fill="${pale}" stroke="${edge}" stroke-width="1.6"/><text x="573" y="86" text-anchor="middle" fill="${ink}" font-size="27">Enzyme-coding gene</text></g>
 <g id="strength-control"><text x="53" y="202" font-size="27" fill="${ink}" font-weight="700">Promoter strength</text><path d="M410 192H746" stroke="${edge}" stroke-width="7" stroke-linecap="round"/><text x="410" y="231" font-size="18" fill="${ink}">Lower</text><text x="746" y="231" font-size="18" fill="${ink}" text-anchor="end">Higher</text><g id="strength-knob"><circle cx="450" cy="192" r="15" fill="${accent}" stroke="${pale}" stroke-width="3"/></g></g>
 <g id="abundance-stage"><path d="M414 241V260m-6 -8 6 8 6-8" fill="none" stroke="${edge}" stroke-width="2.5"/>
 <rect x="42" y="269" width="744" height="114" rx="20" fill="${pale}" stroke="${edge}" stroke-width="1.5"/><text x="72" y="336" fill="${ink}" font-size="28" font-weight="700">Enzyme abundance</text>${enzymes}</g>
 <g id="capacity-stage"><path d="M414 395V424m-6 -8 6 8 6-8" fill="none" stroke="${edge}" stroke-width="2.5"/><rect x="42" y="433" width="744" height="111" rx="20" fill="#eee3f7" stroke="${edge}" stroke-width="1.5"/><text x="72" y="501" fill="${ink}" font-size="28" font-weight="700">Catalytic capacity</text>${reactionRows}</g>
</svg>`;
const css=readFileSync(new URL('layout.css',import.meta.url),'utf8');
const switchAt=at('promoter')-.32;
const abundanceAt=at('enzyme')-.12;
const capacityAt=at('catalytic')-.12;
const html=`<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=1920,height=1080"><title>Promoter engineering — purple glass explanation panel</title><script src="assets/gsap.min.js"></script><style>${css}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="${duration}" data-width="1920" data-height="1080">
 <div class="background"><video id="background-video" class="clip" src="background.mp4" data-start="0" data-duration="${duration}" data-track-index="0" muted playsinline></video></div>
 <div class="speaker-zone" data-layout-allow-overflow><video id="a-roll" class="clip" src="source.mp4" data-start="0" data-duration="${duration}" data-track-index="1" data-has-audio="true" playsinline></video></div>
 <aside id="panel">
  <section id="overview" class="scene"><div class="scene-content"><header class="scene-header"><p class="eyebrow">GLYCAN LIBRARY DESIGN</p><h1>Complexity into opportunity</h1></header><div class="diagram">${complexity}</div></div></section>
  <section id="determinants" class="scene"><div class="scene-content"><header class="scene-header"><p class="eyebrow">DESIGN OPPORTUNITIES</p><h1>Promoter engineering</h1></header><div class="diagram">${mechanism}</div></div></section>
  <div class="progress-rail" data-layout-ignore><div id="progress-fill"></div></div>
 </aside>
</div><script>
window.__timelines=window.__timelines||{};
const tl=gsap.timeline({paused:true});
tl.from('#panel',{opacity:0,y:12,duration:.48,ease:'power2.out'},.12);
tl.from('#overview .eyebrow',{opacity:0,y:6,duration:.3,ease:'sine.out'},.28);
tl.from('#overview h1',{opacity:0,y:10,duration:.4,ease:'power3.out'},.34);
tl.from('#complexity',{opacity:0,y:8,duration:.4,ease:'power2.out'},${Math.max(.8,at('complexity')-.2).toFixed(2)});
tl.from('#opportunity-arrow',{opacity:0,x:-8,duration:.34,ease:'sine.out'},${(at('design')-.24).toFixed(2)});
tl.from('#opportunities',{opacity:0,x:8,duration:.4,ease:'power3.out'},${(at('design')-.1).toFixed(2)});
tl.to('#design-knob-0',{x:36,duration:.6,ease:'sine.inOut'},3.25);
tl.to('#design-knob-1',{x:-26,duration:.6,ease:'power2.inOut'},3.32);
tl.to('#design-knob-2',{x:42,duration:.6,ease:'power1.inOut'},3.39);
// Dip through the glass background while handing the diagram to the next topic.
tl.to('#overview',{opacity:0,duration:.12,ease:'power2.in'},${switchAt.toFixed(2)});
tl.fromTo('#determinants',{opacity:0},{opacity:1,duration:.22,ease:'power2.out'},${(switchAt+.12).toFixed(2)});
tl.from('#determinants .eyebrow',{opacity:0,y:6,duration:.28,ease:'sine.out'},${(switchAt+.18).toFixed(2)});
tl.from('#determinants h1',{opacity:0,y:8,duration:.35,ease:'power3.out'},${(switchAt+.22).toFixed(2)});
tl.from('#promoter-gene',{opacity:0,y:8,duration:.36,ease:'power2.out'},${(at('promoter')+.04).toFixed(2)});
tl.from('#strength-control',{opacity:0,duration:.3,ease:'sine.out'},${(at('can')-.12).toFixed(2)});
tl.to('#strength-knob',{x:245,duration:1.35,ease:'power1.inOut'},${(at('tune')-.08).toFixed(2)});
tl.from('#abundance-stage',{opacity:0,y:6,duration:.32,ease:'power2.out'},${abundanceAt.toFixed(2)});
for(let i=3;i<9;i++)tl.from('#extra-enzyme-'+i,{opacity:0,duration:.22,ease:'sine.out'},${(abundanceAt+.18).toFixed(2)}+(i-3)*.10);
tl.from('#capacity-stage',{opacity:0,y:6,duration:.32,ease:'power3.out'},${capacityAt.toFixed(2)});
for(let i=0;i<3;i++){
 tl.from('#reaction-'+i,{opacity:0,duration:.22,ease:'sine.out'},${(capacityAt+.10).toFixed(2)}+i*.12);
 tl.to('#flux-'+i,{x:160,duration:.72,ease:'none'},${(capacityAt+.38).toFixed(2)}+i*.14);
}
tl.from('#progress-fill',{scaleX:0,duration:${duration-.6},ease:'none'},.3);
window.__timelines.main=tl;
</script></body></html>`;
writeFileSync(new URL('index.html',import.meta.url),html);
