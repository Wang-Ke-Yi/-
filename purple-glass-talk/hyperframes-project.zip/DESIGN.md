# Purple glass talking-head frame

## Style Prompt
Use the user's requested purple glass bottom frame. Present the complete laboratory explanation in a crisp, uncropped video window on a translucent purple glass backplate. A blurred, purple-tinted duplicate of the footage gives the surrounding glass a live background. Use rounded corners, fine lavender reflections and restrained light movement. No subtitles, headings, labels, logos or other visible text.

## Colors
- #1c102e: deep violet background
- #7043af: violet ambient tint
- #a88ae6: lavender glass body
- #e6d9ff: pale violet edge reflections
- #532a83: lower glass rail

## Typography
No on-screen text. Do not generate captions.

## Motion
Keep all 13.2 seconds of footage. Animate only decorative light and the glass reflection. Do not crop, retime or recolor the foreground speaker footage. Retain the original MOV's AAC audio stream unchanged in the delivered MP4.

## What NOT to Do
- No subtitles or explanatory text.
- No unrelated scientific diagrams.
- No glass overlay crossing the speaker's face.
- No replacement speech or background music.
- No crop that removes hands or laboratory context.
