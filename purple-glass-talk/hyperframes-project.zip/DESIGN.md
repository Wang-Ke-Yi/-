# Purple glass scientific explanation panel

## Style Prompt
Match the supplied reference screenshot: the speaker occupies the left half of the original laboratory scene, with a large translucent rounded scientific explanation panel on the right. The panel is pale purple glass, with plum headings and restrained purple schematics. Replace the previous full-video border treatment. Keep the 13.2-second original narration and do not add spoken-word subtitles. Short diagram titles and labels are required by the reference style.

## Colors
- #eee7fa: pale lavender glass body
- #523466: plum headings and labels
- #8152a2: purple links and icons
- #ae90c2: light violet outlines
- #f8f3fd: inset diagram cards

## Typography
Embed DejaVu Sans regular and bold. Use 43px headings and 27–28px diagram labels. Use the provided English narration to make two diagram topics: glycan diversity without a direct template, and the four determinants of glycan output. Do not create sentence-by-sentence captions.

## Motion
Reframe the original foreground video 455px to the left, preserving the speaker's face, torso and gestures. A soft background duplicate fills the space behind the glass. Introduce the panel gently, then reveal the four determining factors. Retain all 13.2 seconds and copy the original MOV's AAC audio stream unchanged.

## What NOT to Do
- No bottom caption band or verbatim narration subtitles.
- No border around the entire video.
- No DNA template graphic that suggests glycans are directly templated.
- No glass overlay crossing the speaker's face.
- No replacement speech or background music.
