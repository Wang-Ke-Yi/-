import {readFileSync,writeFileSync} from 'node:fs';

// Align the user-provided narration locally; these are diagram cues, not captions.
const wordTimings=JSON.parse(readFileSync(new URL('word-timings.json',import.meta.url),'utf8'));
const startsAt=(word)=>wordTimings.find(w=>w.word===word).start;
const factorCueTimes=['enzyme','localization','substrate','reaction'].map(word=>(startsAt(word)-.1).toFixed(2));

const colors={ink:'#523466',accent:'#8152a2',edge:'#ae90c2',pale:'#f8f3fd',node:'#b891d0'};
const {ink,accent,edge,pale,node}=colors;
const nodeCircle=(x,y,r=11)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${node}" stroke="${accent}" stroke-width="2.2"/>`;
const linkage=(d)=>`<path d="${d}" fill="none" stroke="${accent}" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>`;
function glycan(x,y,variant=0,scale=1){
 const branches=[
  [[0,0],[0,-54],[-49,-96],[49,-96],[-49,-148],[49,-148]],
  [[0,0],[0,-54],[-49,-96],[49,-96],[95,-132]],
  [[0,0],[0,-54],[0,-105],[-49,-148],[49,-148],[49,-198]]
 ][variant];
 const links=variant===0?'M0 0V-54L-49 -96V-148M0 -54L49 -96V-148':variant===1?'M0 0V-54L-49 -96M0 -54L49 -96 95 -132':'M0 0V-105L-49 -148M0 -105L49 -148V-198';
 return `<g class="glycan" transform="translate(${x} ${y}) scale(${scale})">${linkage(links)}${branches.map(([a,b])=>nodeCircle(a,b)).join('')}</g>`;
}
const intro=`<svg width="828" height="548" viewBox="0 0 828 548" aria-hidden="true">
 <g id="template-callout"><rect x="224" y="26" width="380" height="62" rx="31" fill="${pale}" stroke="${edge}" stroke-width="1.5"/><text x="414" y="66" font-size="28" font-weight="700" text-anchor="middle" fill="${ink}">No direct template</text></g>
 <g id="diversity-network">
  ${glycan(143,380,0,1.18)}${glycan(399,380,1,1.18)}${glycan(665,380,2,1.02)}
  <path d="M143 425H665" stroke="${edge}" stroke-width="1.3"/>
  <path d="M143 416v18M399 416v18M665 416v18" stroke="${edge}" stroke-width="1.3"/>
 </g>
 <text id="context-label" x="414" y="492" text-anchor="middle" fill="${ink}" font-size="28">Biosynthetic context shapes structure</text>
</svg>`;

const iconPaths=[
 `<path d="M32 10a22 22 0 1 0 0 44l-8-17Z" fill="${accent}"/><circle cx="41" cy="21" r="6" fill="${node}"/>`,
 `<path d="M29 57S10 37 10 24a19 19 0 1 1 38 0C48 37 29 57 29 57Z" fill="${accent}"/><circle cx="29" cy="24" r="7" fill="${pale}"/>`,
 `<rect x="7" y="10" width="17" height="17" rx="4" fill="${accent}"/><rect x="32" y="10" width="17" height="17" rx="4" fill="${node}"/><rect x="7" y="35" width="17" height="17" rx="4" fill="${node}"/><rect x="32" y="35" width="17" height="17" rx="4" fill="${accent}"/>`,
 `<path d="M7 13H44V28H15V44H45" fill="none" stroke="${accent}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path d="M38 36l10 8-10 8Z" fill="${accent}"/>`
];
const labels=[['Enzyme','activity'],['Localization',''],['Substrate','availability'],['Reaction','order']];
const ys=[30,158,286,414];
const cards=labels.map((label,i)=>`<g id="factor-${i}" class="factor">
 <rect x="8" y="${ys[i]}" width="351" height="101" rx="17" fill="${pale}" stroke="${edge}" stroke-width="1.5"/>
 <g transform="translate(29 ${ys[i]+20})">${iconPaths[i]}</g>
 <text x="105" y="${ys[i]+(label[1]?43:61)}" fill="${ink}" font-size="27" font-weight="700">${label[0]}</text>
 ${label[1]?`<text x="105" y="${ys[i]+76}" fill="${ink}" font-size="27" font-weight="700">${label[1]}</text>`:''}
 <path d="M359 ${ys[i]+50}H425V276H492" fill="none" stroke="${edge}" stroke-width="2.6"/>
 </g>`).join('');
const factors=`<svg width="828" height="548" viewBox="0 0 828 548" aria-hidden="true">
 ${cards}
 <g id="glycan-output"><rect x="492" y="132" width="323" height="288" rx="26" fill="#eee3f7" stroke="${edge}" stroke-width="1.5"/>
 ${glycan(650,345,0,1.05)}
 <text x="654" y="394" text-anchor="middle" fill="${ink}" font-size="28" font-weight="700">Glycan output</text></g>
</svg>`;

const html=`<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=1920,height=1080"><title>Purple glass explanation panel — no subtitles</title><script src="assets/gsap.min.js"></script><style>
@font-face{font-family:PanelSans;src:url('assets/DejaVuSans.ttf')}@font-face{font-family:PanelSans;src:url('assets/DejaVuSans-Bold.ttf');font-weight:700}
*{box-sizing:border-box}html,body{margin:0;width:1920px;height:1080px;overflow:hidden;background:#d7d4db;font-family:PanelSans,sans-serif;color:${ink}}
#root{position:relative;width:1920px;height:1080px;overflow:hidden}
.background{position:absolute;inset:0;overflow:hidden}#background-video{width:100%;height:100%;object-fit:cover}
.speaker-zone{position:absolute;left:0;top:0;width:1080px;height:1080px;overflow:hidden;mask-image:linear-gradient(to right,#000 0%,#000 92%,rgba(0,0,0,0) 100%)}
#a-roll{position:absolute;left:-455px;top:0;width:1920px;height:1080px;object-fit:contain}
#panel{position:absolute;left:970px;top:124px;width:900px;height:836px;border-radius:32px;overflow:hidden;background:linear-gradient(135deg,rgba(246,240,255,.94),rgba(228,215,244,.91));backdrop-filter:blur(26px);border:2px solid rgba(255,255,255,.8);box-shadow:0 14px 46px rgba(65,43,84,.16),inset 0 1px 0 rgba(255,255,255,.6)}
.scene{position:absolute;inset:0;overflow:hidden}#overview{opacity:1}#determinants{opacity:0}
.scene-content{width:100%;height:100%;padding:34px;display:flex;flex-direction:column;gap:28px}
.scene-header{display:flex;flex-direction:column;gap:18px;flex:none}.eyebrow{margin:0;font-size:18px;line-height:25px;letter-spacing:1.8px;color:#76528e;font-weight:700}h1{font-size:43px;line-height:54px;letter-spacing:-1px;font-weight:700;margin:0}.diagram{flex:none;width:828px;height:548px}svg{display:block;overflow:visible}
.progress-rail{position:absolute;left:36px;right:36px;bottom:29px;height:2px;background:rgba(142,105,168,.18);overflow:hidden}#progress-fill{width:100%;height:100%;transform-origin:left center;background:#a182bb}
</style></head><body><div id="root" data-composition-id="main" data-start="0" data-duration="13.2" data-width="1920" data-height="1080">
 <div class="background"><video id="background-video" class="clip" src="background.mp4" data-start="0" data-duration="13.2" data-track-index="0" muted playsinline></video></div>
 <div class="speaker-zone" data-layout-allow-overflow><video id="a-roll" class="clip" src="source.mp4" data-start="0" data-duration="13.2" data-track-index="1" data-has-audio="true" playsinline></video></div>
 <aside id="panel">
  <section id="overview" class="scene"><div class="scene-content"><header class="scene-header"><p class="eyebrow">GLYCAN LIBRARY DESIGN</p><h1>Source of glycan diversity</h1></header><div class="diagram">${intro}</div></div></section>
  <section id="determinants" class="scene"><div class="scene-content"><header class="scene-header"><p class="eyebrow">BIOSYNTHETIC DETERMINANTS</p><h1>What shapes glycan output?</h1></header><div class="diagram">${factors}</div></div></section>
  <div class="progress-rail" data-layout-ignore><div id="progress-fill"></div></div>
 </aside>
</div><script>
window.__timelines=window.__timelines||{};
const tl=gsap.timeline({paused:true});
tl.from('#panel',{opacity:0,y:12,duration:.48,ease:'power2.out'},.12);
tl.from('#overview .eyebrow',{opacity:0,y:6,duration:.3,ease:'sine.out'},.28);
tl.from('#overview h1',{opacity:0,y:10,duration:.4,ease:'power3.out'},.34);
tl.from('#template-callout',{opacity:0,y:8,duration:.35,ease:'power2.out'},4.5);
tl.from('#diversity-network .glycan',{opacity:0,y:'+=10',duration:.55,ease:'sine.out',stagger:.16},1.05);
tl.from('#context-label',{opacity:0,duration:.4,ease:'power1.out'},2.1);
// A short dip between diagram topics keeps labels from crossing each other.
tl.to('#overview',{opacity:0,duration:.12,ease:'power2.in'},6.0);
tl.fromTo('#determinants',{opacity:0},{opacity:1,duration:.22,ease:'power2.out'},6.12);
tl.from('#determinants .eyebrow',{opacity:0,y:6,duration:.28,ease:'sine.out'},6.18);
tl.from('#determinants h1',{opacity:0,y:8,duration:.35,ease:'power3.out'},6.22);
tl.from('#glycan-output',{opacity:0,duration:.4,ease:'power1.out'},6.3);
[${factorCueTimes.join(',')}].forEach((time,i)=>tl.from('#factor-'+i,{opacity:0,x:-12,duration:.36,ease:['power2.out','sine.out','power3.out','expo.out'][i]},time));
tl.from('#progress-fill',{scaleX:0,duration:12.7,ease:'none'},.3);
window.__timelines.main=tl;
</script></body></html>`;
writeFileSync(new URL('index.html',import.meta.url),html);
