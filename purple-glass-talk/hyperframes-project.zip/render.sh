#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if command -v chromium >/dev/null 2>&1; then
  export HYPERFRAMES_BROWSER_PATH="$(command -v chromium)"
fi
export npm_config_cache="${npm_config_cache:-$PWD/.npm-cache}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$PWD/.cache}"
node build.mjs
npx --yes hyperframes@0.8.181 check --snapshots --at 2.6,5.4,8.3,10.9,12.7
npx --yes hyperframes@0.8.181 render --output rendered.mp4 --fps 30 --quality high --workers 2 --strict
ffmpeg -hide_banner -loglevel warning -y -i rendered.mp4 -i original-audio.m4a \
  -map 0:v:0 -map 1:a:0 -c copy -t 13.2 -movflags +faststart purple-glass-no-subtitles.mp4
