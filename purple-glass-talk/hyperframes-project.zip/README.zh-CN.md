# 紫色玻璃底框讲解视频

按照用户要求添加紫色半透明玻璃底框，无字幕、无屏幕文字。保留 13.2 秒完整讲解、人物完整画幅及原始 AAC 音轨；未添加配乐或替换配音。

## 工程内容

- `index.html`：1920×1080 HyperFrames 合成，紫色玻璃底板和动态反光。
- `source.mp4`：为浏览器兼容而从用户 MOV 转换的 H.264 素材。
- `background.mp4`：同一素材缩小、模糊并去除声音的背景层。
- `original-audio.m4a`：从用户 MOV 原样复制的 AAC 音轨。
- `assets/gsap.min.js`：本地动画依赖。
- `render.sh`：检查、HyperFrames 渲染、原声音轨合成。

需要 Node.js 22+、FFmpeg 和 Chrome/Chromium。执行 `bash render.sh` 可重新导出。使用的 HyperFrames 版本为 0.8.181。

最终文件为 `purple-glass-no-subtitles.mp4`。原片是 30 fps，输出保持 30 fps。
