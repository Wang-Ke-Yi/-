# 左侧人物＋右侧紫色玻璃讲解面板

按照用户提供的截图重做布局：人物讲解位于左侧，右侧是紫色半透明圆角玻璃面板，包含标题和随讲解展开的示意图。不加口播字幕。保留 13.2 秒完整讲解及原始 AAC 音轨，未添加配乐或替换配音。

内容基于用户提供的 `narration.txt`：糖链没有直接模板；酶活性、定位、底物可用性和反应顺序影响糖链产物。糖链图形为概念示意，不代表特定单糖序列。

## 工程内容

- `build.mjs`：布局、图解与动画的可编辑源文件，生成 `index.html`。
- `index.html`：1920×1080 HyperFrames 合成。
- `narration.txt`：用户提供的讲解原文，用于图解内容设计，不作为字幕显示。
- `word-timings.json`：原文与音频的本地强制对齐结果，用于四个因素的入场时间，不生成字幕。
- `source.mp4`：为浏览器兼容而从用户 MOV 转换的 H.264 素材。
- `background.mp4`：同一素材缩小、模糊并去除声音的背景层，填充玻璃面板后的区域。
- `original-audio.m4a`：从用户 MOV 原样复制的 AAC 音轨。
- `assets/`：本地 GSAP 动画依赖和字体。
- `render.sh`：检查、HyperFrames 渲染、原声音轨合成。

需要 Node.js 22+、FFmpeg 和 Chrome/Chromium。执行 `bash render.sh` 可重新导出。使用的 HyperFrames 版本为 0.8.181。

最终文件为 `purple-glass-no-subtitles.mp4`。原片是 30 fps，输出保持 30 fps。
