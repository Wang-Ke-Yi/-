# Integrase DNA-state writers — left glass panel

## Style Prompt
Continue the approved pale purple glass explanation series. The speaker is on the right in this source, so place the 900 × 836 panel at x=70, y=124. Preserve the full 1920 × 1080 source composition without translation, crop, mirror, background duplication, background blur, or panel backdrop blur. Keep original narration and its timing. Diagram labels and headings only; no narration subtitles or music.

## Colors
- #eee7fa: pale purple glass
- #523466: headings and labels
- #8152a2: active DNA sites and writer
- #ae90c2: outlines
- #b891d0: secondary DNA site half
- #f8f3fd: inset backgrounds

## Typography
Use the existing local DejaVu Sans regular and bold. Match the previous clips: 43px headings, 25–30px labels, 18px eyebrow.

## Scientific structure
1. A schematic population with different DNA-state combinations; serine integrases serve as directional writers.
2. Generic attachment-site exchange: attB + attP produces hybrid attL + attR junctions. Exchange products are inefficiently recognized again, supporting a stable state. This is a site-level schematic, not a specified integration, inversion, or excision geometry. Do not claim absolute irreversibility; directionality can depend on cofactors.
3. Four candidates revealed in narration order: φBT1, TP901-1, Bxb1, φC31. A generic multilayer DNA diagram summarizes the stated goal; it does not assign candidates to particular targets or claim validated orthogonality.

## Motion
Restrained 0.35–0.5s entrances synced to transcript cues; 0.4s horizontal scene transitions inside the panel. Do not animate the source footage.

## What NOT to Do
- No background alterations, feathered source masks, mirroring, duplicated video layers, or CSS backdrop blur.
- No narration captions, added voice, or background music.
- No absolute irreversible lock or experimentally verified orthogonality claim.
- Do not specify DNA sequences or exact target layer assignments.
