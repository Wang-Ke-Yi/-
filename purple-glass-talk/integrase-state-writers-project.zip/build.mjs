import {readFileSync,writeFileSync} from 'node:fs';
const duration=28;
const timing=JSON.parse(readFileSync(new URL('word-timings.json',import.meta.url),'utf8'));
const at=(word,n=0)=>timing.filter(w=>w.word.replace(/\(\d+\)$/,'')===word)[n].start;
const ink='#523466',accent='#8152a2',edge='#ae90c2',pale='#f8f3fd',soft='#b891d0';
const text=(x,y,s,size=26,extra='')=>`<text x="${x}" y="${y}" font-size="${size}" fill="${ink}" ${extra}>${s}</text>`;
const dna=(x,y,w=150)=>`<path d="M${x} ${y-4}h${w}m-${w} 8h${w}" stroke="${edge}" stroke-width="2.5" fill="none"/>`;
const arrow=(x,y)=>`<path d="M${x} ${y}h58m-12-10 12 10-12 10" stroke="${accent}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`;
const cells=Array.from({length:6},(_,i)=>{
 const x=48+(i%3)*264,y=66+Math.floor(i/3)*155;
 const bits=[(i>>2)&1,(i>>1)&1,i&1];
 return `<g class="population-cell"><rect x="${x}" y="${y}" width="208" height="112" rx="56" fill="${pale}" stroke="${edge}" stroke-width="2"/>${dna(x+23,y+56,162)}${bits.map((v,j)=>`<rect x="${x+39+j*47}" y="${y+42}" width="34" height="28" rx="5" fill="${v?accent:'#e4d5ef'}" stroke="${accent}" stroke-width="1.2"/>`).join('')}</g>`;
}).join('');
const population=`<svg width="828" height="548" viewBox="0 0 828 548" aria-hidden="true">
 <g id="population-caption">${text(414,30,'A population of DNA states',26,'text-anchor="middle"')}</g>
 ${cells}
 <g id="writer"><rect x="191" y="365" width="446" height="67" rx="33" fill="#e7d9f2" stroke="${edge}" stroke-width="1.5"/>${text(414,408,'Serine integrases',30,'text-anchor="middle" font-weight="700"')}</g>
 <g id="directional">${text(135,503,'DNA state A',27,'font-weight="700"')}${arrow(385,494)}${text(484,503,'DNA state B',27,'font-weight="700"')}</g>
</svg>`;
function site(x,y,label,kind,id){
 const left=kind==='P'?soft:accent,right=kind==='B'?accent:soft;
 const halves=kind==='L'?[accent,soft]:kind==='R'?[soft,accent]:[left,right];
 return `<g id="${id}">${dna(x,y,270)}<path d="M${x+77} ${y-19}h57v38h-57Z" fill="${halves[0]}"/><path d="M${x+134} ${y-19}h44l19 19-19 19h-44Z" fill="${halves[1]}"/><path d="M${x+134} ${y-17}v34" stroke="#f8f3fd" stroke-width="1.5"/>${text(x+135,y+63,label,29,'font-weight="700" text-anchor="middle"')}</g>`;
}
const exchange=`<svg width="828" height="548" viewBox="0 0 828 548" aria-hidden="true">
 <g id="input-sites">${text(414,35,'Recognition sites',26,'text-anchor="middle"')}${site(76,100,'attB','B','attb')}${text(414,110,'+',32,'text-anchor="middle"')}${site(482,100,'attP','P','attp')}</g>
 <g id="exchange-arrow"><path d="M414 187v64m-12-13 12 13 12-13" stroke="${accent}" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>${text(451,229,'Exchange',24)}</g>
 <g id="junctions">${site(76,300,'attL','L','attl')}${text(414,310,'+',32,'text-anchor="middle"')}${site(482,300,'attR','R','attr')}${text(414,405,'New DNA junctions',28,'font-weight="700" text-anchor="middle"')}</g>
 <g id="low-recognition">${text(414,459,'Inefficient re-recognition',25,'text-anchor="middle"')}</g>
 <g id="stable"><path d="M265 504l11 11 22-25" stroke="${accent}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" fill="none"/>${text(459,516,'Stable DNA state',29,'text-anchor="middle" font-weight="700"')}</g>
</svg>`;
const names=['φBT1','TP901-1','Bxb1','φC31'];
const candidates=names.map((name,i)=>{
 const x=32+(i%2)*398,y=28+Math.floor(i/2)*150;
 return `<g id="candidate-${i}"><rect x="${x}" y="${y}" width="366" height="120" rx="22" fill="${pale}" stroke="${edge}" stroke-width="1.5"/>${text(x+126,y+70,name,32,'font-weight="700"')}${dna(x+30,y+60,70)}<path d="M${x+54} ${y+44}h19l10 16-10 16h-19Z" fill="${accent}"/></g>`;
}).join('');
const layers=[0,1,2].map((_,i)=>`<g class="editing-layer">${dna(272,399+i*49,285)}<rect x="${318+i*38}" y="${386+i*49}" width="56" height="26" rx="5" fill="${i===1?soft:accent}"/><path d="M590 ${399+i*49}l7 7 14-18" fill="none" stroke="${accent}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></g>`).join('');
const multi=`<svg width="828" height="548" viewBox="0 0 828 548" aria-hidden="true">${candidates}
 <g id="layer-caption">${text(414,357,'Editing across multiple layers',27,'font-weight="700" text-anchor="middle"')}</g>${layers}
</svg>`;
const css=readFileSync(new URL('layout.css',import.meta.url),'utf8');
const scene=(id,eyebrow,title,diagram)=>`<section id="${id}" class="scene" data-layout-allow-overflow data-layout-allow-occlusion><div class="scene-content"><header class="scene-header"><p class="eyebrow">${eyebrow}</p><h1>${title}</h1></header><div class="diagram">${diagram}</div></div></section>`;
const s2=at('after')-.28,s3=at('chose')-.3;
const html=`<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=1920,height=1080"><title>Integrase DNA-state writers — left glass panel</title><script src="assets/gsap.min.js"></script><style>${css}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="${duration}" data-width="1920" data-height="1080">
 <video id="a-roll" class="clip" src="source.mp4" data-start="0" data-duration="${duration}" data-track-index="0" muted playsinline></video>
 <audio id="original-narration" src="original-audio.m4a" data-start="0" data-duration="${duration}" data-track-index="1" data-volume="1"></audio>
 <aside id="panel">
  ${scene('population','COMBINATORIAL EDITING','Combinatorial DNA states',population)}
  ${scene('exchange','DIRECTIONAL STATE WRITING','Exchange writes a stable state',exchange)}
  ${scene('candidates','SERINE INTEGRASES','Four integrase candidates',multi)}
  <div class="progress-rail" data-layout-ignore><div id="progress-fill"></div></div>
 </aside>
</div><script>
window.__timelines=window.__timelines||{};
const tl=gsap.timeline({paused:true});
tl.from('#panel',{opacity:0,y:12,duration:.48,ease:'power2.out'},.12);
tl.from('#population .eyebrow',{opacity:0,y:6,duration:.3,ease:'sine.out'},.28);
tl.from('#population h1',{opacity:0,y:10,duration:.4,ease:'power3.out'},.34);
tl.from('#population-caption',{opacity:0,duration:.35,ease:'sine.out'},.65);
tl.from('.population-cell',{opacity:0,y:8,duration:.45,ease:'power2.out',stagger:.17},.95);
tl.from('#writer',{opacity:0,y:8,duration:.45,ease:'power3.out'},${at('serine')-.12});
tl.from('#directional',{opacity:0,x:-10,duration:.45,ease:'sine.out'},${at('directional')-.12});
// Panel-only horizontal pushes transfer the complete outgoing diagram.
tl.fromTo('#exchange',{x:900,opacity:0},{x:0,opacity:1,duration:.4,ease:'power2.inOut'},${s2});
tl.to('#population',{x:-900,duration:.4,ease:'power2.inOut'},${s2});
tl.set('#population',{opacity:0,x:0},${s2+.4});
tl.from('#exchange .eyebrow',{opacity:0,y:6,duration:.3,ease:'sine.out'},${s2+.18});
tl.from('#exchange h1',{opacity:0,y:10,duration:.4,ease:'power3.out'},${s2+.23});
tl.from('#input-sites',{opacity:0,duration:.4,ease:'power2.out'},${s2+.37});
tl.from('#exchange-arrow',{opacity:0,y:-6,duration:.4,ease:'sine.out'},${at('exchange')-.05});
tl.from('#junctions',{opacity:0,y:-7,duration:.5,ease:'power3.out'},${at('new')-.12});
tl.from('#low-recognition',{opacity:0,duration:.45,ease:'power2.out'},${at('efficiently')-.12});
tl.from('#stable',{opacity:0,y:6,duration:.45,ease:'sine.out'},${at('stable')-.12});
tl.fromTo('#candidates',{x:900,opacity:0},{x:0,opacity:1,duration:.4,ease:'power2.inOut'},${s3});
tl.to('#exchange',{x:-900,duration:.4,ease:'power2.inOut'},${s3});
tl.set('#exchange',{opacity:0,x:0},${s3+.4});
tl.from('#candidates .eyebrow',{opacity:0,y:6,duration:.3,ease:'sine.out'},${s3+.18});
tl.from('#candidates h1',{opacity:0,y:10,duration:.4,ease:'power3.out'},${s3+.23});
${[at('phi'),at('tee'),at('bee'),at('phi',1)].map((t,i)=>`tl.from('#candidate-${i}',{opacity:0,y:8,duration:.42,ease:'${['power2.out','sine.out','power3.out','power2.out'][i]}'},${t-.12});`).join('\n')}
tl.from('#layer-caption',{opacity:0,y:6,duration:.4,ease:'sine.out'},${at('editing')-.15});
tl.from('.editing-layer',{opacity:0,x:-10,duration:.4,ease:'power3.out',stagger:.16},${at('editing')+.25});
tl.from('#progress-fill',{scaleX:0,duration:${duration-.6},ease:'none'},.3);
window.__timelines.main=tl;
</script></body></html>`;
writeFileSync(new URL('index.html',import.meta.url),html);
