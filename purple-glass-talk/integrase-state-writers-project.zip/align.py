from pocketsphinx import Decoder
from pathlib import Path
import json, wave, re
s=Path('narration.txt').read_text().lower().replace('—',' ').replace('dna-state','dna state').replace('phi-bt1','phi btone').replace('tp901-1','tee pee nine oh one one').replace('bxb1','bee ex bee one').replace('phi-c31','phi see thirty one')
s=re.sub('[^a-z ]',' ',s)
s=' '.join(s.split())
d=Decoder(samprate=16000,loglevel='ERROR')
custom={'combinatorially':'K AA M B AH N AH T AO R IY AH L IY','serine':'S EH R IY N','integrases':'IH N T AH G R EY S IH Z','btone':'B IY T IY W AH N','tee':'T IY','pee':'P IY','bee':'B IY','ex':'EH K S'}
for w,ph in custom.items():
 if not d.lookup_word(w): d.add_word(w,ph)
for w in s.split():
 if not d.lookup_word(w): raise ValueError(w)
d.set_align_text(s)
with wave.open('alignment.wav') as f: data=f.readframes(f.getnframes())
d.start_utt(); d.process_raw(data,full_utt=True); d.end_utt()
r=[{'word':w.word,'start':w.start_frame/100,'end':(w.end_frame+1)/100} for w in d.seg() if w.word not in ('<sil>','<s>','</s>')]
Path('word-timings.json').write_text(json.dumps(r,indent=2))
print(json.dumps(r))
