import {writeFileSync} from 'node:fs';

const pink='#d98db3', ink='#642d48', line='#a84673', white='#fff5fa';
const wells=Array.from({length:70},(_,i)=>`<circle cx="${38+(i%14)*21}" cy="${16+Math.floor(i/14)*9}" r="2.2" fill="${white}" stroke="${line}" stroke-width=".65"/>`).join('');
const plate=(x,y,content='',fill=pink)=>`<g transform="translate(${x} ${y}) skewX(-32)"><path d="M0 0H360V72H0Z" fill="${fill}" stroke="${line}" stroke-width="1.6"/><path d="M0 72H360" stroke="${white}" stroke-width="4"/>${content}</g>`;
// A single outlined void joins both circular ports to the rectangular chamber.
const adhesiveVoid=`<path d="M55 17H305V32H326 A6.5 6.5 0 1 1 326 40H305V55H55V40H34 A6.5 6.5 0 1 1 34 32H55Z" fill="${white}" stroke="${line}" stroke-width="1.2"/>`;
const arrows=`<g fill="${line}" stroke="${line}" stroke-width="1.6">${[150,280,410].map(x=>`<path d="M${x} 140v22"/><path d="M${x-4} 157l4 7 4-7Z"/>`).join('')}</g>`;
const label=(n,y,title,sub,sub2='')=>`<g fill="${ink}"><circle cx="514" cy="${y-7}" r="14" fill="${line}"/><text x="514" y="${y}" text-anchor="middle" fill="${white}" font-size="19">${n}</text><text x="538" y="${y}" font-size="21" font-weight="700">${title}</text><text x="502" y="${y+36}" font-size="18">${sub}</text>${sub2?`<text x="502" y="${y+62}" font-size="18">${sub2}</text>`:''}</g>`;
const svg=(h,body)=>`<svg xmlns="http://www.w3.org/2000/svg" width="746" height="${h}" viewBox="0 0 746 ${h}" aria-hidden="true">${body}</svg>`;
const scene1=svg(490,`
<g id="array-layer">${plate(110,65,wells)}${label(1,91,'Blind-hole array','Closed-end wells','Openings face chamber ↓')}</g>
${arrows}
<g id="adhesive-layer">${plate(110,217,adhesiveVoid)}${label(2,247,'Acrylic adhesive','PET-based / 0.14 mm')}</g>
<g id="pet-layer">${plate(110,369,`<circle cx="28" cy="36" r="4" fill="${white}" stroke="${line}"/><circle cx="332" cy="36" r="4" fill="${white}" stroke="${line}"/>`,'#ead6e1')}${label(3,398,'Clear PET base','82 × 35 × 0.20 mm')}</g>`);

const scene2=svg(350,`
<g id="chamber-graphic"><rect x="38" y="55" width="670" height="270" rx="8" fill="${pink}" stroke="${line}" stroke-width="2"/>
<path id="connected-chamber" d="M125 125H621V183H653 A11 11 0 1 1 653 197H621V255H125V197H93 A11 11 0 1 1 93 183H125Z" fill="${white}" stroke="${line}" stroke-width="2"/>
<text x="373" y="187" fill="${ink}" font-size="32" font-weight="700" text-anchor="middle">62 × 16 mm</text>
<text x="373" y="224" fill="${ink}" font-size="24" text-anchor="middle">Oil-phase main chamber</text></g>`);

// Assemble the three-layer core before adding any retaining frame.
const skew=.624869;
const project=(x,y,xx,yy)=>({x:x+xx-skew*yy,y:y+yy});
const coreX=128,coreY=144;
const portCentres=[28,332].map(x=>project(coreX,coreY+14,x,36));
const ring=(x,y)=>`<g transform="translate(${x} ${y}) skewX(-32)"><path d="M-20-10H380V82H-20ZM15 9V63H345V9Z" fill="#cf7da5" fill-rule="evenodd" stroke="${line}" stroke-width="2"/></g>`;
const hardwarePoints=[[-10,0],[370,0],[-10,72],[370,72]].map(([x,y])=>project(coreX,coreY,x,y));
const hex=(x,y,r)=>Array.from({length:6},(_,i)=>`${(x+r*Math.cos(i*Math.PI/3)).toFixed(2)},${(y+r*Math.sin(i*Math.PI/3)).toFixed(2)}`).join(' ');
const bolt=(p,i)=>`<g id="bolt-${i}"><path d="M${p.x} ${p.y-12}V${p.y+37}" stroke="${line}" stroke-width="5"/><path d="M${p.x-3} ${p.y+22}h6m-6 5h6m-6 5h6" stroke="${white}" stroke-width="1"/><polygon points="${hex(p.x,p.y-13,8)}" fill="${line}" stroke="${ink}" stroke-width="1"/><path d="M${p.x-4} ${p.y-13}h8" stroke="${white}" stroke-width="1.5"/></g>`;
const nut=(p,i)=>`<g id="nut-${i}"><polygon points="${hex(p.x,p.y+35,8)}" fill="#c8739c" stroke="${line}" stroke-width="1.5"/><circle cx="${p.x}" cy="${p.y+35}" r="3" fill="${white}" stroke="${line}" stroke-width="1"/></g>`;
const scene3=svg(425,`
<g id="assembly-frame-bottom" class="retaining-frame">${ring(coreX,coreY+21)}</g>
<g id="assembly-pet">${plate(coreX,coreY+14,`<circle cx="28" cy="36" r="6" fill="${white}" stroke="${line}"/><circle cx="332" cy="36" r="6" fill="${white}" stroke="${line}"/>`,'#ead6e1')}</g>
<g id="assembly-adhesive">${plate(coreX,coreY+7,adhesiveVoid)}</g>
<g id="assembly-array">${plate(coreX,coreY,wells)}</g>
<g id="silicone-pads">${portCentres.map((p,i)=>`<g id="silicone-${i}"><rect x="${p.x-19}" y="${p.y+10}" width="38" height="17" rx="4" fill="#eab8cf" stroke="${line}" stroke-width="1.5"/><ellipse cx="${p.x}" cy="${p.y+15}" rx="7" ry="3" fill="${white}" stroke="${line}" stroke-width="1"/></g>`).join('')}</g>
<g id="port-connectors">${portCentres.map((p,i)=>`<g id="connector-${i}"><path d="M${p.x-13} ${p.y+28}H${p.x+13}V${p.y+39}H${p.x+7}V${p.y+64}H${p.x-7}V${p.y+39}H${p.x-13}Z" fill="#d98db3" stroke="${line}" stroke-width="1.7"/><path d="M${p.x} ${p.y+28}v34" stroke="${white}" stroke-width="5"/><path d="M${p.x-9} ${p.y+47}h18m-18 7h18" stroke="${line}" stroke-width="2"/></g>`).join('')}</g>
<g id="assembly-frame-top" class="retaining-frame">${ring(coreX,coreY-9)}</g>
<g id="bolts">${hardwarePoints.map(bolt).join('')}</g>
<g id="nuts">${hardwarePoints.map(nut).join('')}</g>
<g fill="${ink}" font-size="21">
 <g id="silicone-label"><path d="M${portCentres[1].x+20} ${portCentres[1].y+17}H490" fill="none" stroke="${line}" stroke-width="1.3"/><text x="500" y="${portCentres[1].y+17}">Cut silicone</text><text x="500" y="${portCentres[1].y+43}">double-sided pads</text></g>
 <g id="connector-label"><text x="76" y="325">Inlet</text><text x="389" y="325">Outlet</text><path d="M${portCentres[0].x} ${portCentres[0].y+66}v28m304-28v28" fill="none" stroke="${line}" stroke-width="1.3"/></g>
 <g id="clamp-label"><text x="500" y="102">Close the frame</text><text x="500" y="131">Bolts + nuts</text><text x="500" y="160">at four corners</text><path d="M490 123H463L${hardwarePoints[1].x} ${hardwarePoints[1].y-12}" fill="none" stroke="${line}" stroke-width="1.3"/></g>
</g>
<g id="assembly-sequence" fill="${ink}"><text x="373" y="383" font-size="23" font-weight="700" text-anchor="middle">Stack → pads → ports → clamp</text></g>`);

// Shallow, uneven closed-end pockets fit individual droplets closely.
const wellXs=Array.from({length:6},(_,i)=>160+i*84);
const depths=[21,18,23,20,22,19];
let blindOutline='M80 96H666V178';
for(let i=wellXs.length-1;i>=0;i--){
 const x=wellXs[i],top=178-depths[i];
 blindOutline+=`H${x+13}Q${x+11} 173 ${x+13} 167Q${x+14} ${top+3} ${x+3} ${top}Q${x-8} ${top-1} ${x-12} ${top+8}L${x-13} 178`;
}
blindOutline+='H80Z';
let randomState=21851;
const rand=()=>{randomState=(Math.imul(randomState,1664525)+1013904223)>>>0;return randomState/4294967296;};
const bulk=[];
for(let attempt=0;attempt<10000&&bulk.length<58;attempt++){
 const p={x:140+rand()*491,y:211+rand()*64,r:6.3+rand()*1.1};
 if(bulk.every(q=>Math.hypot(p.x-q.x,p.y-q.y)>p.r+q.r+1.2))bulk.push(p);
}
const tubePath='M22 329H110V273M636 273V329H724';
const scene4=svg(405,`
<text x="87" y="39" font-size="22" fill="${ink}">Shallow, irregular blind wells</text>
<rect x="80" y="178" width="586" height="106" fill="${white}" stroke="${line}" stroke-width="2"/>
<rect x="80" y="178" width="20" height="106" fill="${line}"/><rect x="646" y="178" width="20" height="106" fill="${line}"/>
<path d="${blindOutline}" fill="${pink}" stroke="${line}" stroke-width="2"/>
<rect x="80" y="284" width="586" height="20" fill="#ead6e1" stroke="${line}" stroke-width="2"/>
<g id="flow-ports"><path d="${tubePath}" fill="none" stroke="${line}" stroke-width="19" stroke-linejoin="round"/><path d="${tubePath}" fill="none" stroke="${white}" stroke-width="14" stroke-linejoin="round"/>
<rect x="95" y="304" width="30" height="10" rx="2" fill="#eab8cf" stroke="${line}"/><rect x="621" y="304" width="30" height="10" rx="2" fill="#eab8cf" stroke="${line}"/>
<path d="M102 306h16v27h-16Zm526 0h16v27h-16Z" fill="${pink}" stroke="${line}"/><path d="M110 304v30m526-30v30" stroke="${white}" stroke-width="8"/>
<text x="25" y="383" font-size="25" fill="${ink}" font-weight="700">Inlet</text><text x="648" y="383" font-size="25" fill="${ink}" font-weight="700">Outlet</text>
<path d="M30 355h49m-10-7 10 7-10 7M668 355h49m-10-7 10 7-10 7" fill="none" stroke="${line}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></g>
<g id="free-droplets" fill="#c26391" stroke="${white}" stroke-width="1">${bulk.map((p,i)=>`<circle id="free-${i}" cx="0" cy="0" r="${p.r.toFixed(2)}"/>`).join('')}</g>
<g id="captured-droplets" fill="#b94c82" stroke="${white}" stroke-width="1">${wellXs.map((x,i)=>`<ellipse id="capture-${i}" cx="0" cy="0" rx="8.3" ry="7.8"/>`).join('')}</g>
<g id="incoming-droplets" fill="#c26391" stroke="${white}" stroke-width="1">${Array.from({length:12},(_,i)=>`<circle id="incoming-${i}" cx="0" cy="0" r="6.3"/>`).join('')}</g>
<g id="outgoing-droplets" fill="#c26391" stroke="${white}" stroke-width="1">${Array.from({length:7},(_,i)=>`<circle id="outgoing-${i}" cx="0" cy="0" r="6.1"/>`).join('')}</g>`);

const scene=(i,eyebrow,title,diagram,notes)=>`<section id="scene${i}" class="scene"><div class="scene-content"><header class="scene-header"><p class="eyebrow">${eyebrow}</p><h1>${title}</h1></header><div class="diagram">${diagram}</div><div class="notes">${notes}</div></div></section>`;
const html=`<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=814,height=764"><title>Flow cell — corrected three-layer structure</title><script src="assets/gsap.min.js"></script><style>
@font-face{font-family:CardSans;src:url('assets/DejaVuSans.ttf')}@font-face{font-family:CardSans;src:url('assets/DejaVuSans-Bold.ttf');font-weight:700}
*{box-sizing:border-box}html,body{margin:0;width:814px;height:764px;overflow:hidden;background:#f0dfe9;font-family:CardSans,sans-serif;color:${ink}}
#root{width:814px;height:764px;position:relative;overflow:hidden;background:#f0dfe9}
.scene{position:absolute;inset:0;background:#f0dfe9;overflow:hidden}#scene1{z-index:1}#scene2{z-index:2;opacity:0}#scene3{z-index:3;opacity:0}#scene4{z-index:4;opacity:0}
.scene-content{width:100%;height:100%;padding:30px 34px;display:flex;flex-direction:column;gap:16px}
.scene-header{flex:none;display:flex;flex-direction:column;gap:18px}.eyebrow{margin:0;color:#94365f;font-size:18px;line-height:24px;font-weight:700}h1{margin:0;font-size:38px;font-weight:700;line-height:48px;letter-spacing:-.7px}.diagram{flex:none}svg{display:block;overflow:visible}.notes{display:flex;flex-direction:column;gap:22px;font-size:23px;line-height:1.4}.notes p{margin:0}.notes .small{font-size:20px}.notes .strong{font-size:25px;font-weight:700}.foot{margin-top:auto;font-size:14px;color:#94365f}#scene1 .notes{margin-top:auto}#scene1 .notes .small{font-size:19px}#scene2 .notes{gap:24px}#scene3 .notes{gap:20px}#scene4 .notes{gap:18px}#scene-transition{position:absolute;inset:0;background:#f0dfe9;opacity:0;z-index:19;pointer-events:none}.border{position:absolute;inset:0;border:2px solid #fff5fa;border-radius:30px;z-index:20;pointer-events:none}
</style></head><body><div id="root" data-composition-id="main" data-start="0" data-duration="19.4" data-width="814" data-height="764">
${scene(1,'FLOW CELL / EXPLODED VIEW','Three layers, one cell',scene1,'<p class="small">Blind-hole array + adhesive + clear PET base</p>')}
${scene(2,'PATTERNED ADHESIVE','Cut out the chamber',scene2,'<p class="strong">Retained perimeter seals the cell</p><p>Inlet / outlet channels connect to the chamber</p><p class="small">0.14 mm PET-based acrylic double-sided adhesive</p>')}
${scene(3,'ASSEMBLY / PADS, PORTS & CLAMP','Connect, then clamp',scene3,'<p class="small">Silicone pads seal both port holes from below.</p><p class="small">Attach the ports, then bolt the frame closed.</p>')}
${scene(4,'DROPLET CAPTURE / SECTION','Many flow in. Some are trapped.',scene4,'<p class="strong">Small droplets fit closely into shallow wells.</p><p class="small">Many uncaptured droplets remain below the array.</p>')}
<div id="scene-transition" data-layout-ignore></div><div class="border" data-layout-ignore></div></div><script>
window.__timelines=window.__timelines||{};
const tl=gsap.timeline({paused:true});
const starts=[0,4.8,8.2,14.0];
starts.forEach((t,i)=>{
 const id='#scene'+(i+1);
 if(i>0){
  // Dip through the panel color so adjacent sets of labels never overlap.
  tl.to('#scene-transition',{opacity:1,duration:.12,ease:'power2.in'},t);
  tl.set('#scene'+i,{opacity:0},t+.12);
  tl.set(id,{opacity:1},t+.12);
  tl.to('#scene-transition',{opacity:0,duration:.18,ease:'power2.out'},t+.12);
 }
 tl.from(id+' .eyebrow',{opacity:0,y:8,duration:.28,ease:'sine.out'},t+.1);
 tl.from(id+' h1',{opacity:0,y:10,duration:.36,ease:'power3.out'},t+.14);
 tl.from(id+' .diagram',{opacity:0,y:12,duration:.44,ease:'power2.out'},t+.23);
 tl.from(id+' .notes p',{opacity:0,y:8,duration:.36,ease:'sine.out',stagger:.12},t+.7);
});
['array-layer','adhesive-layer','pet-layer'].forEach((id,i)=>tl.from('#'+id,{opacity:0,y:-14,duration:.5,ease:'power2.out'},.4+i*.44));
// The initial stack is frame-free. Pads and connectors attach underneath.
['assembly-pet','assembly-adhesive','assembly-array'].forEach((id,i)=>tl.from('#'+id,{opacity:0,y:-22-i*8,duration:.42,ease:'power2.out'},8.55+i*.22));
tl.from('#silicone-pads',{opacity:0,y:32,duration:.45,ease:'power3.out'},9.48);
tl.from('#silicone-label',{opacity:0,duration:.3,ease:'sine.out'},9.6);
tl.from('#port-connectors',{opacity:0,y:37,duration:.45,ease:'power2.out'},10.18);
tl.from('#connector-label',{opacity:0,duration:.3,ease:'sine.out'},10.4);
tl.from('#assembly-frame-top',{opacity:0,y:-38,duration:.5,ease:'power3.out'},11.12);
tl.from('#assembly-frame-bottom',{opacity:0,y:25,duration:.5,ease:'power3.out'},11.12);
tl.from('#clamp-label',{opacity:0,duration:.35,ease:'sine.out'},11.45);
tl.from('#bolts',{opacity:0,y:-26,duration:.45,ease:'power2.out'},11.9);
tl.from('#nuts',{opacity:0,y:20,duration:.42,ease:'power3.out'},12.35);
tl.to('#bolts',{y:3,duration:.25,ease:'sine.inOut'},12.8);
tl.to('#nuts',{y:-2,duration:.25,ease:'sine.inOut'},12.8);
tl.from('#assembly-sequence',{opacity:0,duration:.3,ease:'sine.out'},12.85);
// Follow the visible inlet and its bend before entering the chamber.
function enter(selector,t,x,y,travel=.9){
 tl.fromTo(selector,{x:24,y:329,opacity:0},{x:100,y:329,opacity:1,duration:.3,ease:'none'},t);
 tl.to(selector,{x:110,y:315,duration:.12,ease:'sine.inOut'},t+.3);
 tl.to(selector,{x:110,y:270,duration:.23,ease:'none'},t+.42);
 tl.to(selector,{x:x,y:y,duration:travel,ease:'power1.out'},t+.65);
}
const bulkTargets=${JSON.stringify(bulk)};
bulkTargets.forEach((p,i)=>enter('#free-'+i,14.44+i*.031,p.x,p.y,.75+(i%5)*.045));
const captureX=${JSON.stringify(wellXs)};
captureX.forEach((x,i)=>{
 const t=14.48+i*.3;
 enter('#capture-'+i,t,x,210,.65+i*.035);
 tl.to('#capture-'+i,{y:169,duration:.55,ease:'sine.out'},t+1.3+i*.035);
});
for(let i=0;i<12;i++)enter('#incoming-'+i,17.05+i*.13,185+i*27,199+(i%3)*14,1.0);
for(let i=0;i<7;i++){
 const t=17.25+i*.18,sel='#outgoing-'+i;
 tl.fromTo(sel,{x:606,y:265,opacity:0},{x:636,y:273,opacity:1,duration:.23,ease:'none'},t);
 tl.to(sel,{x:636,y:320,duration:.3,ease:'none'},t+.23);
 tl.to(sel,{x:648,y:329,duration:.12,ease:'sine.inOut'},t+.53);
 tl.to(sel,{x:725,y:329,duration:.43,ease:'none'},t+.65);
 tl.to(sel,{opacity:0,duration:.1,ease:'none'},t+1.04);
}
window.__timelines.main=tl;
</script></body></html>`;
writeFileSync(new URL('index.html',import.meta.url),html);
