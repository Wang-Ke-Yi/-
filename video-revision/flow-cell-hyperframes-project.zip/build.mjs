import {writeFileSync} from 'node:fs';

const pink='#d98db3', ink='#642d48', line='#a84673', white='#fff5fa';
const wells=Array.from({length:70},(_,i)=>`<circle cx="${38+(i%14)*21}" cy="${16+Math.floor(i/14)*9}" r="2.2" fill="${white}" stroke="${line}" stroke-width=".65"/>`).join('');
const plate=(x,y,content='',fill=pink)=>`<g transform="translate(${x} ${y}) skewX(-32)"><path d="M0 0H360V72H0Z" fill="${fill}" stroke="${line}" stroke-width="1.6"/><path d="M0 72H360" stroke="${white}" stroke-width="4"/>${content}</g>`;
// A single outlined void joins both circular ports to the rectangular chamber.
const adhesiveVoid=`<path d="M55 17H305V32H326 A6.5 6.5 0 1 1 326 40H305V55H55V40H34 A6.5 6.5 0 1 1 34 32H55Z" fill="${white}" stroke="${line}" stroke-width="1.2"/>`;
const arrows=`<g fill="${line}" stroke="${line}" stroke-width="1.6">${[150,280,410].map(x=>`<path d="M${x} 140v22"/><path d="M${x-4} 157l4 7 4-7Z"/>`).join('')}</g>`;
const label=(n,y,title,sub,sub2='')=>`<g fill="${ink}"><circle cx="514" cy="${y-7}" r="14" fill="${line}"/><text x="514" y="${y}" text-anchor="middle" fill="${white}" font-size="19">${n}</text><text x="538" y="${y}" font-size="21" font-weight="700">${title}</text><text x="502" y="${y+36}" font-size="18">${sub}</text>${sub2?`<text x="502" y="${y+62}" font-size="18">${sub2}</text>`:''}</g>`;
const svg=(h,body)=>`<svg xmlns="http://www.w3.org/2000/svg" width="746" height="${h}" viewBox="0 0 746 ${h}" aria-hidden="true">${body}</svg>`;
const scene1=svg(490,`
<g id="array-layer">${plate(110,65,wells)}${label(1,91,'Blind-hole array','Closed-end wells','Openings face chamber ↓')}</g>
${arrows}
<g id="adhesive-layer">${plate(110,217,adhesiveVoid)}${label(2,247,'Acrylic adhesive','PET-based / 0.14 mm')}</g>
<g id="pet-layer">${plate(110,369,`<circle cx="28" cy="36" r="4" fill="${white}" stroke="${line}"/><circle cx="332" cy="36" r="4" fill="${white}" stroke="${line}"/>`,'#ead6e1')}${label(3,398,'Clear PET base','82 × 35 × 0.20 mm')}</g>`);

const scene2=svg(350,`
<g id="chamber-graphic"><rect x="38" y="55" width="670" height="270" rx="8" fill="${pink}" stroke="${line}" stroke-width="2"/>
<path id="connected-chamber" d="M125 125H621V183H653 A11 11 0 1 1 653 197H621V255H125V197H93 A11 11 0 1 1 93 183H125Z" fill="${white}" stroke="${line}" stroke-width="2"/>
<text x="373" y="187" fill="${ink}" font-size="32" font-weight="700" text-anchor="middle">62 × 16 mm</text>
<text x="373" y="224" fill="${ink}" font-size="24" text-anchor="middle">Oil-phase main chamber</text></g>`);

const frame=plate(100,92,`<path d="M34 15H330V57H34Z" fill="${white}" stroke="${line}" stroke-width="1.5"/>`,'#cf7da5');
const scene3=svg(385,`
<g id="assembly-pet">${plate(90,263,'','#ead6e1')}</g>
<g id="assembly-adhesive">${plate(90,219,adhesiveVoid)}</g>
<g id="assembly-array">${plate(90,174,wells)}</g>
<g id="assembly-frame">${frame}</g>
<g id="assembly-labels" fill="${ink}" font-size="23"><text x="490" y="143">3D-printed</text><text x="490" y="175">retaining frame</text><path d="M477 151H445" stroke="${line}" stroke-width="2"/><text x="490" y="299">Ports + tubing</text></g>
<g id="tubing" fill="none" stroke-linejoin="round"><path d="M94 303v56H55M410 303v56h46" stroke="${line}" stroke-width="7"/><path d="M94 303v56H55M410 303v56h46" stroke="${white}" stroke-width="4"/><rect x="86" y="292" width="16" height="18" rx="3" fill="${pink}" stroke="${line}"/><rect x="402" y="292" width="16" height="18" rx="3" fill="${pink}" stroke="${line}"/></g>`);

// One continuous array body: the well floors are integral, not an extra glass layer.
const wellXs=Array.from({length:6},(_,i)=>145+i*84);
let blindOutline='M50 84H696V184';
for(const x of [...wellXs].reverse()) blindOutline+=`H${x+34}V111H${x}V184`;
blindOutline+='H50Z';
const scene4=svg(340,`
<text x="62" y="46" font-size="21" fill="${ink}">Blind-hole array / closed-end wells</text>
<rect x="50" y="184" width="646" height="104" fill="${white}" stroke="${line}" stroke-width="2"/>
<rect x="50" y="184" width="27" height="104" fill="${line}"/><rect x="669" y="184" width="27" height="104" fill="${line}"/>
<path d="${blindOutline}" fill="${pink}" stroke="${line}" stroke-width="2"/>
<rect x="50" y="288" width="646" height="16" fill="#ead6e1" stroke="${line}" stroke-width="2"/>
<g id="droplets" fill="#c26391" stroke="${white}" stroke-width="1.5">${wellXs.map((x,i)=>`<circle id="drop-${i}" cx="${x+17}" cy="127" r="9.5"/>`).join('')}</g>`);

const scene=(i,eyebrow,title,diagram,notes)=>`<section id="scene${i}" class="scene"><div class="scene-content"><header class="scene-header"><p class="eyebrow">${eyebrow}</p><h1>${title}</h1></header><div class="diagram">${diagram}</div><div class="notes">${notes}</div></div></section>`;
const html=`<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=814,height=764"><title>Flow cell — corrected three-layer structure</title><script src="assets/gsap.min.js"></script><style>
@font-face{font-family:CardSans;src:url('assets/DejaVuSans.ttf')}@font-face{font-family:CardSans;src:url('assets/DejaVuSans-Bold.ttf');font-weight:700}
*{box-sizing:border-box}html,body{margin:0;width:814px;height:764px;overflow:hidden;background:#f0dfe9;font-family:CardSans,sans-serif;color:${ink}}
#root{width:814px;height:764px;position:relative;overflow:hidden;background:#f0dfe9}
.scene{position:absolute;inset:0;background:#f0dfe9;overflow:hidden}#scene1{z-index:1}#scene2{z-index:2;opacity:0}#scene3{z-index:3;opacity:0}#scene4{z-index:4;opacity:0}
.scene-content{width:100%;height:100%;padding:30px 34px;display:flex;flex-direction:column;gap:16px}
.scene-header{flex:none;display:flex;flex-direction:column;gap:18px}.eyebrow{margin:0;color:#94365f;font-size:18px;line-height:24px;font-weight:700}h1{margin:0;font-size:38px;font-weight:700;line-height:48px;letter-spacing:-.7px}.diagram{flex:none}svg{display:block;overflow:visible}.notes{display:flex;flex-direction:column;gap:22px;font-size:23px;line-height:1.4}.notes p{margin:0}.notes .small{font-size:20px}.notes .strong{font-size:25px;font-weight:700}.foot{margin-top:auto;font-size:14px;color:#94365f}#scene1 .notes{margin-top:auto}#scene1 .notes .small{font-size:19px}#scene2 .notes{gap:24px}#scene3 .notes{gap:20px}#scene4 .notes{gap:35px}.border{position:absolute;inset:0;border:2px solid #fff5fa;border-radius:30px;z-index:20;pointer-events:none}
</style></head><body><div id="root" data-composition-id="main" data-start="0" data-duration="19.4" data-width="814" data-height="764">
${scene(1,'FLOW CELL / EXPLODED VIEW','Three layers, one cell',scene1,'<p class="small">Blind-hole array + adhesive + clear PET base</p>')}
${scene(2,'PATTERNED ADHESIVE','Cut out the chamber',scene2,'<p class="strong">Retained perimeter seals the cell</p><p>Inlet / outlet channels connect to the chamber</p><p class="small">0.14 mm PET-based acrylic double-sided adhesive</p>')}
${scene(3,'ASSEMBLY / FRAME & PORTS','Seal and connect',scene3,'<p class="strong">Blind-hole array above. Clear PET below.</p><p class="small">The patterned adhesive defines the flow chamber.</p>')}
${scene(4,'DROPLET CAPTURE / SECTION','Flow in. Rise. Capture.',scene4,'<p class="strong">Array openings face the oil chamber</p><p class="strong">Droplets rise into the blind wells</p><p class="small">Clear PET base / flat sealed floor</p>')}
<div class="border" data-layout-ignore></div></div><script>
window.__timelines=window.__timelines||{};
const tl=gsap.timeline({paused:true});
const starts=[0,4.8,8.2,14.0];
starts.forEach((t,i)=>{
 const id='#scene'+(i+1);
 if(i>0){
  // Dip through the panel color so adjacent sets of labels never overlap.
  tl.to('#scene'+i,{opacity:0,duration:.12,ease:'power2.in'},t);
  tl.fromTo(id,{opacity:0},{opacity:1,duration:.2,ease:'power2.out'},t+.12);
 }
 tl.from(id+' .eyebrow',{opacity:0,y:8,duration:.28,ease:'sine.out'},t+.1);
 tl.from(id+' h1',{opacity:0,y:10,duration:.36,ease:'power3.out'},t+.14);
 tl.from(id+' .diagram',{opacity:0,y:12,duration:.44,ease:'power2.out'},t+.23);
 tl.from(id+' .notes p',{opacity:0,y:8,duration:.36,ease:'sine.out',stagger:.12},t+.7);
});
['array-layer','adhesive-layer','pet-layer'].forEach((id,i)=>tl.from('#'+id,{opacity:0,y:-14,duration:.5,ease:'power2.out'},.4+i*.44));
['assembly-pet','assembly-adhesive','assembly-array','assembly-frame'].forEach((id,i)=>tl.from('#'+id,{opacity:0,y:-24-i*4,duration:.65,ease:'power2.out'},8.65+i*.25));
tl.from('#tubing',{opacity:0,duration:.5,ease:'sine.out'},10.65);
for(let i=0;i<6;i++){
 tl.from('#drop-'+i,{opacity:0,duration:.15,ease:'none'},14.75+i*.33);
 tl.from('#drop-'+i,{y:137,duration:1.4+i*.07,ease:'power1.inOut'},14.75+i*.33);
}
window.__timelines.main=tl;
</script></body></html>`;
writeFileSync(new URL('index.html',import.meta.url),html);
