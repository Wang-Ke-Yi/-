#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
ffmpeg -hide_banner -loglevel error -y -f lavfi -i 'color=white:s=814x764,format=gray' \
  -vf "geq=lum='if(lte(pow(max(abs(X-406.5)-377,0),2)+pow(max(abs(Y-381.5)-352,0),2),900),255,0)'" \
  -frames:v 1 rounded-mask.png
ffmpeg -hide_banner -loglevel warning -y \
  -i source.mp4 -i panels.mp4 -loop 1 -i rounded-mask.png \
  -filter_complex '[1:v][2:v]alphamerge[card];[0:v][card]overlay=1048:148:shortest=1:format=auto,format=yuv420p[v]' \
  -map '[v]' -map 0:a:0 -c:v libx264 -preset medium -crf 18 -c:a copy \
  -t 19.4 -movflags +faststart flow-cell-corrected.mp4
