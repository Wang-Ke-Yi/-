#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
node build.mjs
if command -v chromium >/dev/null 2>&1; then
  export HYPERFRAMES_BROWSER_PATH="$(command -v chromium)"
fi
export npm_config_cache="${npm_config_cache:-$PWD/.npm-cache}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$PWD/.cache}"
npx --yes hyperframes@0.8.181 check
npx --yes hyperframes@0.8.181 render --output panels.mp4 --fps 30 --quality high --workers 2 --strict
./compose.sh
