# Flow-cell correction — visual identity

## Style Prompt
Match the supplied 19.4-second laboratory video: a pale blush panel, raspberry technical diagrams, dark plum English labels, restrained entrance animations and explanatory fluid movement. Keep the original four topics and their approximate timing. The overlay is redrawn because only a flattened MP4 was supplied.

## Colors
- #f0dfe9: opaque panel replacing the baked-in graphics
- #fff5fa: chamber voids and clear PET highlights
- #d98db3: array and adhesive material
- #a84673: technical outlines and arrows
- #642d48: labels and headings

## Typography
Use locally embedded DejaVu Sans regular and bold to match the original sans-serif labels. Maintain the original card's approximate 40px heading and 20–26px diagram labels.

## Motion
Gentle 0.3-second crossfades, short upward entrances, layered assembly, deterministic droplets rising into closed-end wells.

## What NOT to Do
- Do not add a separate glass slide or represent the array as through holes.
- Do not add the three adhesive islands in the chamber.
- Do not leave either circular port disconnected from the rectangular chamber.
- Do not alter the talking-head footage, original audio, frame rate, or duration.
- Do not invent a replacement voiceover.
