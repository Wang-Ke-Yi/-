# Flow-cell correction — visual identity

## Style Prompt
Match the supplied 19.4-second laboratory video: a pale blush panel, raspberry technical diagrams, dark plum English labels, restrained entrance animations and explanatory fluid movement. Keep the original four topics and their approximate timing. The overlay is redrawn because only a flattened MP4 was supplied.

## Colors
- #f0dfe9: opaque panel replacing the baked-in graphics
- #fff5fa: chamber voids and clear PET highlights
- #d98db3: array and adhesive material
- #a84673: technical outlines and arrows
- #642d48: labels and headings

## Typography
Use locally embedded DejaVu Sans regular and bold to match the original sans-serif labels. Maintain the original card's approximate 40px heading and 20–26px diagram labels.

## Motion
Gentle 0.3-second color dips, short upward entrances, staged assembly and deterministic droplet flow. Keep the three-layer core free of retaining frames until both silicone adhesive pads and inlet/outlet connectors have attached underneath the PET port holes. Only then close upper/lower retaining frames and tighten four corner bolts and nuts. Show numerous small droplets entering through a visible inlet; six closely fitting droplets rise into shallow irregular blind pockets, while many remain in the chamber below and some leave through the outlet. Well geometry and flow are conceptual, without new numerical dimensions.

## What NOT to Do
- Do not add a separate glass slide or represent the array as through holes.
- Do not add the three adhesive islands in the chamber.
- Do not leave either circular port disconnected from the rectangular chamber.
- Do not alter the talking-head footage, original audio, frame rate, or duration.
- Do not invent a replacement voiceover.
- Do not show the frame before silicone pads and ports are attached.
- Do not use deep rectangular wells or imply every incoming droplet is captured.
